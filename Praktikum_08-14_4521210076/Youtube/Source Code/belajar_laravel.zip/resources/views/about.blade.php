<x-app-layout title="About">
    <x-slot name="heading">About</x-slot>
    About Content
</x-app-layout>