<td class="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
    {{$slot}}
</td>