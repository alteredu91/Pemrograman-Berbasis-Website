<x-app-layout title="Contact">
    <x-slot name="heading">Contact</x-slot>
    Contact Content
</x-app-layout>