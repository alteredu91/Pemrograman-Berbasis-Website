<x-app-layout title="Gallery">
    <x-slot name="heading">Gallery</x-slot>
    Gallery Content
</x-app-layout>