<x-app-layout>
<x-slot name="heading">Home</x-slot>
Home
</x-app-layout>