<thead class="bg-gray-50">
    <?php echo e($slot); ?>

</thead><?php /**PATH C:\Users\ASUS\Documents\belajar_laravel\resources\views/components/table/thead.blade.php ENDPATH**/ ?>