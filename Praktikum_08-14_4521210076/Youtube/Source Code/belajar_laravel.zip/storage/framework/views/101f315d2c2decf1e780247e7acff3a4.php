<?php
    $isActive = request()->routeIs($route ?? '') || request()->fullUrlIs(url($href));
    $classes = $isActive 
        ? 'bg-blue-600 text-white' 
        : 'text-blue-900 hover:bg-white hover:text-black';
?>

<a <?php echo e($attributes->merge(['class' => $classes . ' rounded-md px-3 py-2 text-sm font-medium'])); ?>>
    <?php echo e($slot); ?>

</a>
<?php /**PATH C:\Users\NekoFi\Documents\belajar_laravel\belajar_laravel\resources\views/components/navbar/link.blade.php ENDPATH**/ ?>