<a <?php echo e($attributes); ?>

    class="text-gray-300 hover:bg-gray-700 hover:text-whiteblock rounded-md px-3 py-2 text-base font-medium ">
    <?php echo e($slot); ?>

</a>
<?php /**PATH C:\Users\ASUS\Herd\belajar_laravel\resources\views/components/navbar/dropdown-link.blade.php ENDPATH**/ ?>