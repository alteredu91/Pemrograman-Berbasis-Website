<th scope="col" class="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">
    <?php echo e($slot); ?>

</th><?php /**PATH C:\Users\ASUS\Documents\belajar_laravel\resources\views/components/table/th.blade.php ENDPATH**/ ?>