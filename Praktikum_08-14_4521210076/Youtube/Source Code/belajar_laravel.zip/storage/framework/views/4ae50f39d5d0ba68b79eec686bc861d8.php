<div class="sm:flex-auto">
    <h1 class="text-base font-semibold leading-6 text-gray-900">
        <?php echo e($title); ?>

    </h1>
    <p class="mt-2 text-sm text-gray-700">
        <?php echo e($description); ?>

    </p>
</div><?php /**PATH C:\Users\NekoFi\Documents\belajar_laravel\belajar_laravel\resources\views/components/section-title.blade.php ENDPATH**/ ?>