 <!-- Current: "bg-gray-900 text-white", Default: "text-gray-300 hover:bg-gray-700 hover:text-white"
 aria-current="page"
-->

<a <?php echo e($attributes); ?> class="rounded-md px-3 py-2 text-sm font-medium text-gray-300 hover:bg-gray-700 hover:text-white">
    <?php echo e($slot); ?>

</a>
<?php /**PATH C:\Users\ASUS\Herd\belajar_laravel\resources\views/components/nav-link.blade.php ENDPATH**/ ?>