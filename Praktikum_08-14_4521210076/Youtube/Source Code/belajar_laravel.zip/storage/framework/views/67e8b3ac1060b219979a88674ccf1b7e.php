<div class="-mx-4 -my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
    <div class="inline-block min-w-full py-2 align-middle sm:px-6 lg:px-8">
        <div class="overflow-hidden shadow ring-1 ring-black ring-opacity-5 sm:rounded-lg">
            <table class="min-w-full divide-y divide-gray-300">
                <?php echo e($slot); ?>

            </table>
        </div>
    </div>
</div><?php /**PATH C:\Users\ASUS\Documents\belajar_laravel\resources\views/components/table/index.blade.php ENDPATH**/ ?>