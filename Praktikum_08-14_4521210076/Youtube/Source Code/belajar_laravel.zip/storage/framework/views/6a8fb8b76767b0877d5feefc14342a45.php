<td class="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
    <?php echo e($slot); ?>

</td><?php /**PATH C:\Users\NekoFi\Documents\belajar_laravel\belajar_laravel\resources\views/components/table/td.blade.php ENDPATH**/ ?>