<a <?php echo e($attributes); ?>

    class="<?php echo e(request()->fullUrlIs(url($href)) ? 'bg-light-blue-500 text-white' : 'text-light-blue-500 hover:bg-pink-800 hover:text-white'); ?> rounded-md px-3 py-2 text-sm font-medium">
    <?php echo e($slot); ?>

</a>
<?php /**PATH C:\Users\ASUS\Documents\belajar_laravel\resources\views/components/navbar/link.blade.php ENDPATH**/ ?>