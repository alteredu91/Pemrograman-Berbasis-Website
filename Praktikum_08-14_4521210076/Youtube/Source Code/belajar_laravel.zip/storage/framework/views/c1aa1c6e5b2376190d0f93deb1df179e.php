<tbody class="divide-y divide-gray-200 bg-white">
    <?php echo e($slot); ?>

</tbody><?php /**PATH C:\Users\ASUS\Documents\belajar_laravel\resources\views/components/table/tbody.blade.php ENDPATH**/ ?>